(async () => {

    function isFullscreen() {
        return !!(document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullScreenElement);
    }

    function findElementInShadows(selector) {
        // Check regular DOM
        let element = document.querySelector(selector);
        if (element) return element;

        // Check all shadow roots
        const allElements = document.querySelectorAll('*');
        for (const el of allElements) {
            if (el.shadowRoot) {
            element = el.shadowRoot.querySelector(selector);
            if (element) return element;

            // Recursively check nested shadow roots
            element = findInNestedShadows(el.shadowRoot, selector);
            if (element) return element;
            }
        }

        return null;
    }

    function findInNestedShadows(root, selector) {
        console.log("entering", selector)
        const allElements = root.querySelectorAll('*');
        for (const el of allElements) {
            if (el.shadowRoot) {
            const element = el.shadowRoot.querySelector(selector);
            if (element) return element;

            const nested = findInNestedShadows(el.shadowRoot, selector);
            if (nested) return nested;
            }
        }
        return null;
    }

    function enterFullscreen() {
        // Usage
        const button = findElementInShadows('.fullscreen-icon control');
        button.click()
        console.log('[Disney+ Fullscreen Fix] Restored fullscreen');
    }

    function getFullscreenButton() {
        document.querySelector('video');
        const buttons = document.querySelectorAll('button');
        const controls = document.querySelector('.btm-media-controls');
        if (controls) {
            const lastButton = buttons[buttons.length - 1];
            if (lastButton) {
                console.log('[Disney+ Fullscreen Fix] Clicking last control button (likely fullscreen)');
                lastButton.click();
                return true;
            }
        }
    }

    // const playerUI = document.querySelector('disney-web-player-ui')
    // const shadowRoot = playerUI.shadowRoot;
    const shadowRoot = document.querySelector('toggle-fullscreen').shadowRoot
    const fullscreenButton = shadowRoot.querySelector('info-tooltip button')
    fullscreenButton.clisk()



    // // Stop the retry interval
    // function stopRetrying() {
    //     if (restoreInterval) {
    //         clearInterval(restoreInterval);
    //         restoreInterval = null;
    //         console.log('[Disney+ Fullscreen Fix] Stopped retry attempts');
    //     }
    // }

    // // Start retry interval
    // function startRetrying(reason) {
    //     stopRetrying(); // Clear any existing interval

    //     console.log(`[Disney+ Fullscreen Fix] Starting retry attempts (trigger: ${reason})`);

    //     let attemptCount = 0;

    //     restoreInterval = setInterval(() => {
    //         if (!shouldRestoreFullscreen || !fullscreenExitTime) {
    //             stopRetrying();
    //             return;
    //         }

    //         const timeSinceExit = Date.now() - fullscreenExitTime;

    //         if (timeSinceExit > RESTORE_WINDOW_MS) {
    //             console.log('[Disney+ Fullscreen Fix] Restore window expired, assuming manual exit');
    //             shouldRestoreFullscreen = false;
    //             wasFullscreen = false;
    //             fullscreenExitTime = null;
    //             stopRetrying();
    //             return;
    //         }

    //         // Check if we're ready to restore
    //         const video = document.querySelector('video');
    //         if (video && !isFullscreen() && shouldRestoreFullscreen) {
    //             attemptCount++;
    //             console.log(`[Disney+ Fullscreen Fix] Attempt #${attemptCount} (${timeSinceExit}ms since exit)`);

    //             const clicked = clickFullscreenButton();

    //             // Check if it worked after a short delay
    //             setTimeout(() => {
    //                 if (isFullscreen()) {
    //                     console.log('[Disney+ Fullscreen Fix] ✓ Successfully restored fullscreen!');
    //                     shouldRestoreFullscreen = false;
    //                     stopRetrying();
    //                 }
    //             }, 200);
    //         }
    //     }, RETRY_INTERVAL_MS);
    // }

    // Track fullscreen changes
    function handleFullscreenChange(event) {
        const currentlyFullscreen = isFullscreen();
        console.log(`[Disney+ Fullscreen Fix] Is full screen : ${currentlyFullscreen}`)
        console.log('event', event)

        // if (currentlyFullscreen) {
        //     wasFullscreen = true;
        //     shouldRestoreFullscreen = false;
        //     fullscreenExitTime = null;
        //     stopRetrying();
        //     console.log('[Disney+ Fullscreen Fix] ✓ Entered fullscreen');
        // } else {
        //     if (wasFullscreen) {
        //         fullscreenExitTime = Date.now();
        //         shouldRestoreFullscreen = true;
        //         console.log('[Disney+ Fullscreen Fix] Exited fullscreen, will attempt to restore');

        //         // Start trying to restore
        //         startRetrying('fullscreen exit');
        //     }
        // }
    }

    // Listen for fullscreen changes
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);

    // // Listen for clicks to trigger restore if needed
    // document.addEventListener('click', (e) => {
    //     if (shouldRestoreFullscreen && !restoreInterval) {
    //         console.log('[Disney+ Fullscreen Fix] Click detected, starting retry attempts');
    //         startRetrying('click event');
    //     }
    // }, true);

    // // Monitor for URL changes (when episode changes)
    // let lastUrl = location.href;
    // new MutationObserver(() => {
    //     const currentUrl = location.href;
    //     if (currentUrl !== lastUrl) {
    //         const oldEpisodeId = lastUrl.split('/').pop();
    //         const newEpisodeId = currentUrl.split('/').pop();
    //         lastUrl = currentUrl;

    //         console.log('[Disney+ Fullscreen Fix] URL changed:', oldEpisodeId, '->', newEpisodeId);

    //         if (shouldRestoreFullscreen && !restoreInterval) {
    //             startRetrying('URL change');
    //         }
    //     }
    // }).observe(document, { subtree: true, childList: true });

    function handleManualExitFullscreen(event) {
        if (event.code === 'Escape') {
            console.log('[Disney+ Fullscreen Fix] Escape key pressed')

        }
    }

    document.addEventListener('keydown', e => console.log('[Disney+ Fullscreen Fix] keydown', e))
    await setTimeout(resolve, 1000, () => resolve())
    enterFullscreen()

    console.log('[Disney+ Fullscreen Fix] Extension loaded and monitoring')
})();
